<template>
  <div class="container-fluid">
    <b-row align-h="center">
      <b-col cols="8">
        <div class="mt-5">
          <div class="d-flex-column align-items-center">
            <h2
              class="font-weight-bold d-inline"
            >3 NBA Players Who Agreed To Sign With A Team...But Changed Their Minds!</h2>
            <p class="mt-4">Uploaded By: winso</p>
            <p>View Count: 4</p>
            <b-button variant="primary" class="primary-button">Save to List</b-button>
            <b-button variant="danger" class="primary-button">Report</b-button>
          </div>
          <div class="mt-3">
            <center>
              <img src="https://i.ytimg.com/vi/MyPP0WAueEA/mqdefault.jpg" alt width="640">
            </center>
          </div>
        </div>
      </b-col>
    </b-row>
  </div>
</template>

<script>
export default {
  layout: "home"
};
</script>

<style>
</style>
